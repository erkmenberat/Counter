let counter = 0; 

if(counter == 0){
    document.getElementById("minusbtn").style.opacity = 0.5;
    document.getElementById("minusbtn").disabled = true;
}

document.getElementById("plusbtn").onclick = function(){
    counter ++; 
    document.getElementById("counterLabel").innerHTML = counter;
    if(document.getElementById("plusbtn").onclick){
        document.getElementById("minusbtn").style.opacity = 1;
        document.getElementById("labelforalert").style.visibility = "hidden";
        document.getElementById("minusbtn").disabled = false;
    }
}


document.getElementById("resetbtn").onclick = function(){
    counter = 0; 
    document.getElementById("counterLabel").innerHTML = counter;
    document.getElementById("minusbtn").style.opacity = 0.5;
    document.getElementById("minusbtn").disabled = true;
    
}


document.getElementById("minusbtn").onclick = function(){
    counter --; 
    document.getElementById("counterLabel").innerHTML = counter;
    if(counter == 0){
        document.getElementById("labelforalert").style.visibility = "visible";
        document.getElementById("minusbtn").style.opacity = 0.5;
        document.getElementById("minusbtn").disabled = true;
    }else if(counter > 0){
         document.getElementById("minusbtn").style.opacity = 1;
    }
}

